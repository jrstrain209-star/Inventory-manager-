import Link from "next/link";
import {
  AlertTriangle,
  Boxes,
  Building2,
  CheckCircle2,
  Map as RouteMap,
  PackageSearch,
  Warehouse,
} from "lucide-react";
import { supabase } from "@/lib/supabase";

export const dynamic = "force-dynamic";

type Item = {
  id: string;
  name: string;
  size: string | null;
  unit: string;
  reorder_point: number;
};

type InventoryLevel = {
  item_id: string;
  inventory_location_id: string;
  on_hand: number;
};

type InventoryLocation = {
  id: string;
  name: string;
  location_type: string;
};

type Requirement = {
  item_id: string;
  required_qty: number;
};

type InventoryRow = Item & {
  required: number;
  onHand: number;
  shortage: number;
  locations: Array<{
    name: string;
    quantity: number;
  }>;
};

async function getInventoryData(): Promise<{
  rows: InventoryRow[];
  error: string | null;
}> {
  const [itemsResult, levelsResult, locationsResult, requirementsResult] =
    await Promise.all([
      supabase
        .from("items")
        .select("id, name, size, unit, reorder_point")
        .eq("active", true)
        .order("size"),
      supabase
        .from("inventory_levels")
        .select("item_id, inventory_location_id, on_hand"),
      supabase
        .from("inventory_locations")
        .select("id, name, location_type")
        .eq("active", true),
      supabase
        .from("store_item_requirements")
        .select("item_id, required_qty"),
    ]);

  const firstError = [
    itemsResult.error,
    levelsResult.error,
    locationsResult.error,
    requirementsResult.error,
  ].find(Boolean);

  if (firstError) {
    return {
      rows: [],
      error: firstError.message,
    };
  }

  const levels = (levelsResult.data ?? []) as InventoryLevel[];
  const locations = (locationsResult.data ?? []) as InventoryLocation[];
  const requirements = (requirementsResult.data ?? []) as Requirement[];
  const locationNames = new Map(
    locations.map((location) => [location.id, location.name])
  );

  const rows = ((itemsResult.data ?? []) as Item[])
    .map((item) => {
      const itemLevels = levels.filter((level) => level.item_id === item.id);
      const required = requirements
        .filter((requirement) => requirement.item_id === item.id)
        .reduce((total, requirement) => total + requirement.required_qty, 0);
      const onHand = itemLevels.reduce(
        (total, level) => total + level.on_hand,
        0
      );

      return {
        ...item,
        required,
        onHand,
        shortage: Math.max(required - onHand, 0),
        locations: itemLevels
          .map((level) => ({
            name:
              locationNames.get(level.inventory_location_id) ??
              "Inventory location",
            quantity: level.on_hand,
          }))
          .sort((a, b) => a.name.localeCompare(b.name)),
      };
    })
    .sort((a, b) =>
      (a.size ?? a.name).localeCompare(b.size ?? b.name, undefined, {
        numeric: true,
        sensitivity: "base",
      })
    );

  return { rows, error: null };
}

export default async function InventoryPage() {
  const { rows, error } = await getInventoryData();
  const requiredTotal = rows.reduce((total, row) => total + row.required, 0);
  const onHandTotal = rows.reduce((total, row) => total + row.onHand, 0);
  const shortageTotal = rows.reduce((total, row) => total + row.shortage, 0);
  const shortageSizes = rows.filter((row) => row.shortage > 0).length;

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">Inventory Manager</p>
          <h1>Inventory</h1>
          <p className="subtitle">
            Compare the filters required across all stores with the stock
            currently on hand.
          </p>
        </div>

        <div className="profile-badge" aria-label="User profile">
          JS
        </div>
      </header>

      {error ? (
        <section className="inventory-error" role="alert">
          <AlertTriangle size={22} />
          <div>
            <strong>Inventory could not be loaded.</strong>
            <p>{error}</p>
          </div>
        </section>
      ) : (
        <>
          <section className="inventory-totals" aria-label="Inventory totals">
            <article>
              <ClipboardNumber label="Required" value={requiredTotal} />
            </article>
            <article>
              <Warehouse size={21} />
              <div>
                <span>On hand</span>
                <strong>{onHandTotal}</strong>
              </div>
            </article>
            <article className={shortageTotal > 0 ? "has-shortage" : ""}>
              <AlertTriangle size={21} />
              <div>
                <span>Needed</span>
                <strong>{shortageTotal}</strong>
              </div>
            </article>
            <article>
              <Boxes size={21} />
              <div>
                <span>Short sizes</span>
                <strong>{shortageSizes}</strong>
              </div>
            </article>
          </section>

          <section className="section">
            <div className="section-heading inventory-heading">
              <div>
                <p className="eyebrow">Filter totals</p>
                <h2>Stock by size</h2>
              </div>
              <span className="inventory-count">{rows.length} sizes</span>
            </div>

            <div className="inventory-list">
              {rows.map((row) => {
                const isShort = row.shortage > 0;

                return (
                  <article
                    className={`inventory-card${isShort ? " is-short" : ""}`}
                    key={row.id}
                  >
                    <div className="inventory-item-main">
                      <div className="inventory-size-row">
                        <h3>{row.size ?? row.name}</h3>
                        <span
                          className={`stock-status${
                            isShort ? " shortage" : " ready"
                          }`}
                        >
                          {isShort ? (
                            <>
                              <AlertTriangle size={14} />
                              Need {row.shortage}
                            </>
                          ) : (
                            <>
                              <CheckCircle2 size={14} />
                              Ready
                            </>
                          )}
                        </span>
                      </div>

                      <p>{row.name}</p>

                      <div className="location-breakdown">
                        {row.locations.length > 0 ? (
                          row.locations.map((location) => (
                            <span key={location.name}>
                              {location.name}: {location.quantity}
                            </span>
                          ))
                        ) : (
                          <span>No inventory location recorded</span>
                        )}
                      </div>
                    </div>

                    <dl className="inventory-quantities">
                      <div>
                        <dt>Required</dt>
                        <dd>{row.required}</dd>
                      </div>
                      <div>
                        <dt>On hand</dt>
                        <dd>{row.onHand}</dd>
                      </div>
                    </dl>
                  </article>
                );
              })}
            </div>
          </section>
        </>
      )}

      <nav className="mobile-nav" aria-label="Main navigation">
        <Link className="nav-item" href="/">
          <Boxes size={20} />
          <span>Dashboard</span>
        </Link>
        <Link className="nav-item" href="/stores">
          <Building2 size={20} />
          <span>Stores</span>
        </Link>
        <Link className="nav-item active" href="/inventory">
          <PackageSearch size={20} />
          <span>Inventory</span>
        </Link>
        <Link className="nav-item" href="/routes">
          <RouteMap size={20} />
          <span>Routes</span>
        </Link>
      </nav>
    </main>
  );
}

function ClipboardNumber({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <>
      <PackageSearch size={21} />
      <div>
        <span>{label}</span>
        <strong>{value}</strong>
      </div>
    </>
  );
}
